
import './App.css'
import {Header} from "./components/Header/Header.jsx";
import {Inicio} from "./components/Inicio/Inicio.jsx";
import {Evento} from "./components/Evento/Evento.jsx";
import {Palestrantes} from "./components/Palestrantes/palestrantes.jsx"
import {Oficinas} from './components/Oficinas/oficinas.jsx';
import {Cronograma} from './components/Cronograma/cronograma.jsx';
import {Inscricoes} from './components/Inscricoes/Inscricoes.jsx';
import {Footer} from './components/Footer/footer.jsx';
function App() {
 

  return (
    <main className='mainContainer'>
        <Header />
        <Inicio />
        <Evento />
        <Palestrantes />
        <Oficinas /> 
        <Cronograma />
        <Inscricoes />
        <Footer />

    </main>
    )
}

export default App
