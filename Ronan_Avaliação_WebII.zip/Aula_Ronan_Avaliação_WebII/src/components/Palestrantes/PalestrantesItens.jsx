import "./palestrantes.css"

const P2 = ({ image, header, texto, span }) => {
  return (
    <div className="conteudo">
      <img src={image} alt="Imagem" />
      <div>
        <header>{header}</header>
        <p>{texto}</p>
        <span>{span}</span>
      </div>
    </div>

  )

}

export { P2 };