import "./palestrantes.css"
import { P2 } from "./PalestrantesItens";
import image from "../../assets/images/logo.svg"

const Palestrantes = () => {
  return (
    <div id="P" className="PContainer">
      <header>
        <h1>Palestrantes</h1>
      </header>

      <section className="PConteudo">

        <P2 image={image} header='Palestrante 1' texto='Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.' span='Lear more' />
        <P2 image={image} header='Palestrante 2' texto='Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.' span='Lear more' />
        <P2 image={image} header='Palestrante 3' texto='Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.' span='Lear more' />

      </section>
      <button className='button' type="submit">Cronograma</button>
    </div>
  )
}

export  {Palestrantes};