import "./Oficinas.css";
import {OficinasItens} from "./OficinasItens";
import image from "../../assets/images/logo.svg"

function Oficinas() {
  return (
    <div>
    <h2 class='Conteudo'>Oficinas</h2>

    <section className="PConteudo">
    <OficinasItens header='Oficina 1' texto='Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.' image={image}/>
    <OficinasItens header='Oficina 2' texto='Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.' image={image}/>
    </section>
  </div>
  )
}

export {Oficinas};

