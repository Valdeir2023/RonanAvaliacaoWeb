import "./Oficinas.css";

const OficinasItens = ({image,header,texto}) => {
    return (
        <div className="conteudo">
        <img src={image} alt="Imagem" />
        <div>
          <header>{header}</header>
          <p>{texto}</p>
        </div>
      </div>

    )
  }
  
  export  {OficinasItens};
  
  